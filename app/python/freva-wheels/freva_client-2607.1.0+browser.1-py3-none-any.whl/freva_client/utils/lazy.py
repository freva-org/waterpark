"""Lazy load 'slow' deps.

BROWSER OVERLAY - built by @freva-org/browser-python's prepare-freva-wheelhouse command.

Upstream file: freva_client/utils/lazy.py
Change:        `intake` and `intake_esm` raise a specific, actionable message instead of a generic
               "Optional dependency ... is required for this feature."
Why:           this profile deliberately does not ship intake-esm (its polars pin conflicts with the
               polars the runtime ships), so the failure is expected and should read as a decision
               rather than as a broken install.
Remove when:   upstream makes intake_esm an optional dependency; then no overlay is needed at all.
"""

from importlib import import_module as _mod
from types import ModuleType
from typing import Generic, Optional, TypeVar

LazyType = TypeVar("LazyType", bound=ModuleType)

_BROWSER_UNSUPPORTED = {
    "intake": "intake_catalogue() is not included in the browser profile because\nintake-esm's dependency set is incompatible with this Pyodide runtime.\nUse the standard Freva Python environment for this feature.",
    "intake_esm": "intake_catalogue() is not included in the browser profile because\nintake-esm's dependency set is incompatible with this Pyodide runtime.\nUse the standard Freva Python environment for this feature.",
}


class LazyModule(Generic[LazyType]):
    def __init__(self, module_name: str):
        self._module_name = module_name
        self._module: Optional[LazyType] = None

    def _load(self) -> LazyType:
        if self._module is None:
            unsupported = _BROWSER_UNSUPPORTED.get(self._module_name)
            if unsupported is not None:
                raise NotImplementedError(unsupported)
            try:
                self._module = _mod(self._module_name)  # type: ignore[assignment]
            except ImportError as error:
                raise ImportError(
                    f"Optional dependency '{self._module_name}' is "
                    "required for this feature."
                ) from error
        return self._module

    def __getattr__(self, item: str):
        return getattr(self._load(), item)


intake = LazyModule("intake")
intake_esm = LazyModule("intake_esm")
pd = LazyModule("pandas")
xr = LazyModule("xarray")
